/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author User
 */
import java.util.UUID;

public class Actividad {
    private UUID id;
    private String tipo;
    private String horario;
    private int aforo_max;
    private String sala;

    public Actividad (UUID id, String tipo, String horario, int aforo_max, String sala){
        this.id = id;
        this.tipo=tipo;
        this.horario=horario;
        this.aforo_max= aforo_max;
        this.sala=sala;
    }
    public String getTipo() {
        return tipo;
    }

    public String getHorario() {
        return horario;
    }

    public String getSala() {
        return sala;
    }
}
