import java.util.UUID;

public class Servicios_adicionales{
    private UUID id;
    private String nombre;

    public Servicios_adicionales(UUID id, String nombre){
        this.id = id;
        this.nombre = nombre;
    }
}
