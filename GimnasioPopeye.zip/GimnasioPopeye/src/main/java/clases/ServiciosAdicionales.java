/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author User
 */
import java.util.UUID;

public class ServiciosAdicionales{
    private UUID id;
    private String nombre;

    public ServiciosAdicionales(UUID id, String nombre){
        this.id = id;
        this.nombre = nombre;
    }
}
